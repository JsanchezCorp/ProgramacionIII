import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {
 autor: any = {nombres:'Juan Sebastian Sanchez silva ', apellidos:'harold camilo barrera giraldo'}
}
