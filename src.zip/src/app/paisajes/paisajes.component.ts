import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Paisaje } from './paisaje';


@Component({
  selector: 'app-paisajes',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './paisajes.component.html',
  styleUrl: './paisajes.component.css'
})
export class PaisajesComponent  implements OnInit{


    paisajes: Paisaje[]=[
      { nombre:'Gran Canion',ubicacion:'Estados Unidos', 
        tipo:'Desierto', altitud:2134, longitud: 446},
        { nombre:'Monte Everest',ubicacion:'Nepal', 
          tipo:'Montania', altitud:8848, longitud: 5},
          { nombre:'Selva Amazónica',ubicacion:'Brasil', 
            tipo:'Selva Tropical', altitud:100, longitud: 5500},
    ]
    
    ngOnInit(): void {
    }
  
  }

