export class Paisaje {
    nombre:string;
    ubicacion:string ; 
    tipo: string; 
    altitud :number; 
    longitud :number; 

}
