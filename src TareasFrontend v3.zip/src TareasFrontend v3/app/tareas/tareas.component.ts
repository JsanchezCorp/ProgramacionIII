import { Component, OnInit } from '@angular/core';
import { Tarea } from './tarea';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-tareas',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './tareas.component.html',
  styleUrl: './tareas.component.css'
})

export class TareasComponent implements OnInit {
 
  tareas: Tarea[]=[
    {id:1, nomTarea: 'Caso de uso 1',descripcion: 'Tarea de Angular',fechaCreacion:'2024-09-08',
      responsable:'Juan Sebastian Sanchez Silva', email:'jSanchez@Gmail.com'
    }
  ];

  ngOnInit(): void {
    
  }
}
